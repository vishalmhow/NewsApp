//
//  NewsAppUITests.swift
//  NewsAppUITests
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import XCTest

class NewsAppUITests: XCTestCase {

    var app: XCUIApplication!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        self.continueAfterFailure = false
        
        self.app = XCUIApplication()
        self.app.launch()
    }

    override func tearDownWithError() throws {
        self.app = nil
        try super.tearDownWithError()
    }
    
    func testSelectStateForChart() {
        
        //Wait for News list screen
        XCTAssertTrue(app.navigationBars["News"].waitForExistence(timeout: 5))
        
        //Swipe throught news list
        app.swipeUp()
        app.swipeDown()
        
        //Tap on Covid Tracker button
        app.navigationBars["News"].buttons["Covid Tracker"].tap()
        
        //Tap on National button
        app.navigationBars["Covid Cases"].buttons["National"].tap()
        
        //Tap on the first cell
        app.cells.firstMatch.tap()
        
        XCTAssertFalse(app.navigationBars["Covid Cases"].buttons["National"].exists)
        
    }
    
    func testStateListScreenCloseAction() {
        
        //Wait for News list screen
        XCTAssertTrue(app.navigationBars["News"].waitForExistence(timeout: 5))
        
        //Tap on Covid Tracker button
        app.navigationBars["News"].buttons["Covid Tracker"].tap()
        
        //Tap on National button
        app.navigationBars["Covid Cases"].buttons["National"].tap()
        
        //Tap on close button
        app.navigationBars["Select State"].buttons["close"].tap()
        
        XCTAssertTrue(app.navigationBars["Covid Cases"].exists)
    }
    
    func testOpenNewsDetail() {
        
        //Wait for News list screen
        XCTAssertTrue(app.navigationBars["News"].waitForExistence(timeout: 5))
        
        //Tap on the first cell
        app.cells.firstMatch.tap()
        
        XCTAssertTrue(app.buttons["Done"].waitForExistence(timeout: 5))
    }

}
