//
//  SelectStateViewModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation

class SelectStateViewModel: NSObject {
    
    var stateList = [State]()
    var service: NewsServices? = NewsServices()
    
    convenience init(service: NewsServices?) {
        self.init()
        self.service = service
    }
    
    func fetchStateList (completion: @escaping((Bool, Error?) -> Void)) {
        Task {
            do {
                self.stateList = try await service!.fetchStateListWithAsyncURLSession()
                completion(true, nil)
            } catch {
                print(error.localizedDescription)
                completion(false, error)
            }
        }
    }
}


