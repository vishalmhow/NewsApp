//
//  Constants.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation

struct Constants {
    static let newsCellReuseId = "newsCell"
    static let covidCellReuseId = "covidCell"
    static let filterCellReuseId = "filterCell"
    static let mainStorybaord = "Main"
}
