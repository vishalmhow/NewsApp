//
//  NewsCell.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import UIKit

class NewsCell: UITableViewCell {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var articleImageView: UIImageView!
    
    var cellVM: NewsCellViewModel? {
        didSet {
            if let cellVM = cellVM {
                titleLabel.text = cellVM.title
                descriptionLabel.text = cellVM.description
                let service = NewsServices()
                Task {
                    do {
                        if let imageUrl = URL(string: cellVM.imageUrl ) {
                            let downloadedImage = try await service.downloadImageWithAsyncURLSession(imageUrl: imageUrl) as UIImage?
                            
                            if let downloadedImage = downloadedImage {
                                DispatchQueue.main.async {
                                    self.articleImageView.image = downloadedImage
                                }
                            }
                        }
                    } catch {
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        bgView.layer.shadowOffset = .zero
        bgView.layer.shadowOpacity = 0.7
        bgView.layer.shadowRadius = 7
        bgView.layer.cornerRadius = 10.0
    }
    
    func configureArticleImageView(articaleImage: UIImage) {
        self.articleImageView.image = nil
        DispatchQueue.main.async {
            self.articleImageView.image = articaleImage
        }
    }
}
