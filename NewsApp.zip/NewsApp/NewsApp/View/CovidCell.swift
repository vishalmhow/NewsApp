//
//  CovidCell.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import UIKit

class CovidCell: UITableViewCell {
    
    @IBOutlet weak var covidDataLabel: UILabel!
    
}
