//
//  HTTPClient.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import Foundation

enum NetworkError: Error {
    case noInternet
    case apiFailure
    case invalidStatusCode
    case decodingError
}

struct APIDetails {
    static let baseUrl = "https://newsapi.org/v2/everything?q=tesla&from=2022-01-27&sortBy=publishedAt&apiKey="
    static let covidStateUrl = URL(string: "https://api.covidtracking.com/v2/states.json")
    static let urlKey = "27dd4fff59d54d28a1974af0d18e9e62"
    static let covidTrackingUrl = "https://api.covidtracking.com/v2/us/daily.json"
}

enum DataScope {
    case national
    case state(State)
}

