//
//  SelectStateViewController.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import UIKit

class SelectStateViewController: UIViewController {
    
    @IBOutlet weak var filterTableView: UITableView!
    
    var completion: ((State) -> Void)?
    let viewModel = SelectStateViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = false
        self.fetchStateList()
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(didTapClose))
    }
    
    @objc func didTapClose() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func fetchStateList() {
        self.viewModel.fetchStateList { (status, error) in
            if status {
                DispatchQueue.main.async {
                    self.filterTableView.reloadData()
                }
            }
        }
    }
    
}

extension SelectStateViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.stateList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Constants.filterCellReuseId, for: indexPath) as? FilterCell else {
            return UITableViewCell()
        }
        cell.stateNameLabel.text = self.viewModel.stateList[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.filterTableView.deselectRow(at: indexPath, animated: true)
        let state = self.viewModel.stateList[indexPath.row]
        completion?(state)
        self.navigationController?.popViewController(animated: true)
    }
}
