//
//  CovidViewController.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import UIKit
import Charts

class CovidViewController: UIViewController {
    
    @IBOutlet weak var covidTableView: UITableView!
    @IBOutlet weak var chartView: BarChartView!
    
    let viewModel = CovidViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupViewProperties()
    }
    
    func setupViewProperties() {
        self.navigationController?.navigationBar.tintColor = .black
        addFilterButton()
        fetchCovidData()
    }
    
    func fetchCovidData() {
        self.viewModel.fetchCovidData { (status, error) in
            if status {
                DispatchQueue.main.async {
                    self.chartView.data = self.viewModel.setupBarChartView()
                    self.covidTableView.reloadData()
                }
            }
        }
    }
    
    func addFilterButton() {
        let filterButton = UIBarButtonItem(title: self.viewModel.getFilterButtonTitle(), style: .plain, target: self, action: #selector(filterButtonTapped))
        self.navigationItem.rightBarButtonItem = filterButton
        navigationItem.rightBarButtonItem?.setTitleTextAttributes([.font : UIFont.systemFont(ofSize: 17, weight: .bold), .foregroundColor : UIColor.black], for: .normal)
    }
    
    @objc func filterButtonTapped() {
        guard let stateViewController = UIStoryboard.init(name: Constants.mainStorybaord, bundle: Bundle.main).instantiateViewController(withIdentifier: "SelectStateViewController") as? SelectStateViewController else {
            return
        }
        stateViewController.completion = { state in
            self.viewModel.scope = .state(state)
            _ = self.viewModel.getFilterButtonTitle()
            self.addFilterButton()
            self.fetchCovidData()
        }
        self.navigationController?.pushViewController(stateViewController, animated: true)
    }
}

extension CovidViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.dayData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Constants.covidCellReuseId, for: indexPath) as? CovidCell else {
            return UITableViewCell()
        }
        cell.covidDataLabel.text = self.viewModel.getStringFromDate(dayData: self.viewModel.dayData[indexPath.row])
        return cell
    }
    
}
