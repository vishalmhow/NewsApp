//
//  CovidViewControllerTests.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import XCTest
@testable import NewsApp

class CovidViewControllerTests: XCTestCase {

    var newsServices: MockNewsServices!
    var viewModel: CovidViewModel!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        try super.setUpWithError()
        
        newsServices = MockNewsServices()
        viewModel = CovidViewModel(service: newsServices)
        
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        
        newsServices = nil
        viewModel = nil
        
        try super.tearDownWithError()
    }
    
    func testFetchStateListSuccess() throws {
        
        newsServices.response = newsServices.mockCovidData()
        
        viewModel.fetchCovidData { (status, error) in
            XCTAssertTrue(status)
        }
    }
    
    func testFetchStateListFailureAPIError() throws {
        
        let response = NSError(domain: "", code: 500, userInfo: [NSLocalizedDescriptionKey: "API Error occurred"])
        newsServices.response = response
        
        viewModel.fetchCovidData { (status, error) in
            XCTAssertTrue(error != nil)
        }
    }
    
    func testGetFilterButtonTitleScope() {
        viewModel.scope = .national
        let title = viewModel.getFilterButtonTitle()
        XCTAssertTrue(title == "National")
    }

    func testGetStringFromDate() {
        let dateStr = viewModel.getStringFromDate(dayData: DayData(date: Date(), count: 10))
        XCTAssertTrue(dateStr.count > 0)
    }
    
    func testSetupBarChartView() {
        let dayData = DayData(date: Date(), count: 100)
        viewModel.dayData = [dayData]
        let barChartData = viewModel.setupBarChartView()
        XCTAssertNotNil(barChartData)
    }
}
