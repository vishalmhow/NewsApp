//
//  MockServices.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation
@testable import NewsApp
import UIKit

class MockNewsServices: NewsServices {
    
    public var response: Any? = nil
    public var image: Any? = nil
    
    override func fetchNewsListWithAsyncURLSession() async throws -> [Article] {
        if let _ = self.response as? NSError {
            throw NetworkError.invalidStatusCode
        } else {
            return response as! [Article]
        }
    }
    
    override func fetchCovidDataWithAsyncURLSession(url: URL) async throws -> [DayData] {
        if let _ = self.response as? NSError {
            throw NetworkError.invalidStatusCode
        } else {
            return response as! [DayData]
        }
    }
    
    override func downloadImageWithAsyncURLSession(imageUrl: URL) async throws -> UIImage {
        if let _ = self.response as? NSError {
            throw NetworkError.invalidStatusCode
        } else {
            let image = UIImage()
            return image
        }
    }
    
    func mockNewsData() -> [Article] {
        let bundle = Bundle(for: type(of: self))
        let url = bundle.url(forResource: "MockNewsData", withExtension: "json")!
        let data = try! Data(contentsOf: url)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let newsData = try! decoder.decode(NewsModel.self, from: data)
        return newsData.articles
    }
    
    func mockCovidData() -> [DayData] {
        let bundle = Bundle(for: type(of: self))
        let url = bundle.url(forResource: "MockCovidData", withExtension: "json")!
        let data = try! Data(contentsOf: url)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let result = try! decoder.decode(CovidDataResponse.self, from: data)
        let models: [DayData] = result.data.compactMap {
            guard let date = DateFormatter.dayFormatter.date(from: $0.date), let value = $0.cases?.total.value else {
                return nil
            }
            return DayData(date: date, count: value)
            // return models
        }
        return models
    }
    
    func mockStateData() -> [State] {
        let bundle = Bundle(for: type(of: self))
        let url = bundle.url(forResource: "MockStateData", withExtension: "json")!
        let data = try! Data(contentsOf: url)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let result = try! decoder.decode(StateListResponse.self, from: data)
        return result.data
    }

}
